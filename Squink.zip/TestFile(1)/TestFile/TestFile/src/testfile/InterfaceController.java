/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testfile;

import java.io.File;
import java.io.FilenameFilter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import model.*;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class InterfaceController implements Initializable {
    
    String diretorio, arquivo;

    @FXML
    private TextField txtDiretorio;
    @FXML
    private Button enviar;
    @FXML
    private TextField txtArquivo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onClickEnviar(ActionEvent event) {
        diretorio = txtDiretorio.getText();
        arquivo = txtArquivo.getText();
        
        try {
            
            // Create a file object
            File f = new File(diretorio);
  
            // Create a file object
            FilenameFilter filter = new FilenameFilter() {
  
                public boolean accept(File f, String name)
                {
                    return name.contains(arquivo);
                }
            };
            // Get all the names of the files present
            // in the given directory
            File[] files = f.listFiles(filter);
  
            System.out.println("Files are:");
  
            // Display the names of the files
            for(File file: files){
                System.out.println(file.getName());
            }
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        } 
    }
    
}
