package Database;

import java.sql.*;

public class Connection {

    public static java.sql.Connection createConnection() {
        String url = "jdbc:mysql://localhost:3306/squink";
        String user = "root";
        String password = "";
        try {
            java.sql.Connection connection = DriverManager.getConnection(url, user, password);
            return connection;
        } catch (SQLException e) {
            System.out.println("Database connection error");
        }
        return null;
    }
}