package Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.User;

public class DbMethods {

    public boolean login(String username, String password) {
        String sql = "SELECT * FROM user WHERE username=? AND password=?";

        try (java.sql.Connection connection = Connection.createConnection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.isBeforeFirst()) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return false;
    }

    public void signUp(User user) {
        String sql = "INSERT INTO user (username,email,password) VALUES (?,?,?)";

        try (java.sql.Connection connection = Connection.createConnection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}