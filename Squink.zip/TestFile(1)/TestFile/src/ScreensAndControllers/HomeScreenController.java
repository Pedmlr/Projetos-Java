/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScreensAndControllers;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author ragan
 */
public class HomeScreenController implements Initializable {

    @FXML
    private Button btnExit;
    @FXML
    private Button btnSync;
    @FXML
    private ScrollPane appBox;
    @FXML
    private AnchorPane btnShow;
    @FXML
    private Button btnSend;
    @FXML
    private CheckBox select1;
    @FXML
    private CheckBox select2;
    @FXML
    private CheckBox select3;

    ArrayList<CheckBox> listaCheckBox = new ArrayList();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void onClickEnviar(ActionEvent event) {
        int botao = 2;
        selectApp(botao);
    }

    @FXML
    private void onClickSincronizar(ActionEvent event) {
        int botao = 1;
        selectApp(botao);
    }

    public static void deleteDirectory(File file_sinc) {

        for (File subfile : file_sinc.listFiles()) {

            if (subfile.isDirectory()) {
                deleteDirectory(subfile);
            }

            subfile.delete();
        }
    }

    public static void copyDir(Path src, Path dest) throws IOException {
        Files.walk(src)
                .forEach(source -> {
                    try {
                        Files.copy(source, dest.resolve(src.relativize(source)),
                                StandardCopyOption.REPLACE_EXISTING);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
    }

    public void selectApp(int botao) {
        if (botao == 1) {
            if (select1.isSelected()) {
                String filepath_sinc = "C:\\Users\\ragan\\AppData\\Roaming\\JetBrains";

                String from = "G:\\Meu Drive\\Squink\\JetBrains";

                String to = "C:\\Users\\ragan\\AppData\\Roaming\\JetBrains";

                Sync(filepath_sinc, from, to);
            }

            if (select2.isSelected()) {
                String filepath_sinc = "C:\\Users\\ragan\\AppData\\Roaming\\NetBeans\\8.2";

                String from = "G:\\Meu Drive\\Squink\\NetBeans";

                String to = "C:\\Users\\ragan\\AppData\\Roaming\\NetBeans\\8.2";

                Sync(filepath_sinc, from, to);
            }

            if (select3.isSelected()) {
                String filepath_sinc = "C:\\Users\\ragan\\AppData\\Roaming\\discord";

                String from = "G:\\Meu Drive\\Squink\\Discord";

                String to = "C:\\Users\\ragan\\AppData\\Roaming\\discord";

                Sync(filepath_sinc, from, to);
            }

        }
        if (botao == 2) {
            if (select1.isSelected()) {
                String filepath = "G:\\Meu Drive\\Squink\\JetBrains";

                File file = new File(filepath);

                File from = new File("C:\\Users\\ragan\\AppData\\Roaming\\JetBrains");

                File to = new File("G:\\Meu Drive\\Squink\\JetBrains");

                managerFiles(filepath, file, from, to);
            }
            if (select2.isSelected()) {
                String filepath = "G:\\Meu Drive\\Squink\\NetBeans";

                File file = new File(filepath);

                File from = new File("C:\\Users\\ragan\\AppData\\Roaming\\NetBeans\\8.2");

                File to = new File("G:\\Meu Drive\\Squink\\NetBeans");

                managerFiles(filepath, file, from, to);
            }
            if (select3.isSelected()) {
                String filepath = "G:\\Meu Drive\\Squink\\Discord";

                File file = new File(filepath);

                File from = new File("C:\\Users\\ragan\\AppData\\Roaming\\discord");

                File to = new File("G:\\Meu Drive\\Squink\\Discord");

                managerFiles(filepath, file, from, to);
            }
        }
    }

    public void Sync(String filepath_sinc, String from, String to) {

        File file_sinc = new File(filepath_sinc);

        File from_final = new File(from);

        File to_final = new File(to);

        try {
            deleteDirectory(file_sinc);
            file_sinc.delete();
            System.out.println("Arquivos excluídos.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        try {
            copyDir(from_final.toPath(), to_final.toPath());
            System.out.println("Diretório copiado.");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void managerFiles(String filepath, File file, File from, File to) {
        try {
            deleteDirectory(file);
            file.delete();
            System.out.println("Arquivos excluídos.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        try {
            copyDir(from.toPath(), to.toPath());
            System.out.println("Diretório copiado.");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void btnExitHandle(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void onClickShow(MouseEvent event) {

    }

}
