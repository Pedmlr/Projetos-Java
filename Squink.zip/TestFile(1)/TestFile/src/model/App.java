package model;

public class App {

    private String name;
    private String version;
    private String default_config_path_windows;
    private String default_config;

    public App(String name, String version, String default_config_path_windows, String default_config) {
        this.name = name;
        this.version = version;
        this.default_config_path_windows = default_config_path_windows;
        this.default_config = default_config;
    }

    public App() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDefault_config_path_windows() {
        return default_config_path_windows;
    }

    public void setDefault_config_path_windows(String default_config_path_windows) {
        this.default_config_path_windows = default_config_path_windows;
    }

    public String getDefault_config() {
        return default_config;
    }

    public void setDefault_config(String default_config) {
        this.default_config = default_config;
    }

}
