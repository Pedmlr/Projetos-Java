package model;

public class Config {

    private String config;

    public Config(String config) {
        this.config = config;
    }

    public Config() {
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

}
