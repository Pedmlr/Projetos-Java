
package model;


public class Device {
    private String operational_system;

    public Device(String operational_system) {
        this.operational_system = operational_system;
    }

    public Device() {
    }

    public String getOperational_system() {
        return operational_system;
    }

    public void setOperational_system(String operational_system) {
        this.operational_system = operational_system;
    }
    
    
}
