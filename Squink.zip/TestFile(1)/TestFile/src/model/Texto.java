package model;

public class Texto {
    String diretorio;
    public Texto() {
    }

    public String getDiretorio() {
        return diretorio;
    }

    public void setDiretorio(String diretorio) {
        this.diretorio = diretorio;
    }
   
}
